# Fiverr Project Brief — Health Facility Locator (Google Maps Integration)

See the polished version of this brief (shared directly with candidates) as
a Word document. This copy lives in-repo so it stays version-controlled
alongside the code it scopes.

## Project title
Health Facility Locator — Google Maps API Integration

## Summary
Build a "Health Facility Locator" feature for a live web app (React) that
helps users find the nearest health facilities — hospitals, clinics,
laboratories, pharmacies — based on their current location or a searched
address, using the Google Maps JavaScript API and Places API. Users filter
results by facility type and by service offered (e.g. immunization,
radiology).

## Deliverables
1. Working feature merged into the `dev` branch of the provided repo,
   covering issues #01–#07.
2. Responsive UI (mobile-first) matching provided brand colors.
3. Short handover documentation (issue #07).

## Full scope — see `issues/01` through `issues/07` in this repo for
acceptance criteria per task. Summary:
- Base map render
- Current-location + address search
- Facility markers from a provided dataset, with clustering
- Type + service filters
- List + detail view with click-to-call and "get directions"
- Mobile responsiveness + brand polish
- Testing + handover

## Out of scope
- Native mobile app (web only)
- In-app turn-by-turn navigation (deep-link to Google Maps instead)
- Automated test suite
- Facility data entry/admin tooling
- Backend/API design beyond consuming the provided endpoint

## Required skills
React (hooks), JavaScript/TypeScript, Google Maps JavaScript API + Places
API, REST API consumption, responsive CSS, Git/GitHub workflow (branches,
PRs).

## Timeline
10 working days across 4 milestones (see `docs/PROJECT_BOARD.md`).

## Budget
$450–$650 fixed price across 4 milestones (see the Google Sheet budget tab
for the per-milestone breakdown).

## What we provide
- Repo access (this repo, write access)
- Sandbox Google Maps API key (spend-capped, domain-restricted)
- Sample anonymized facility dataset
- Figma/brand reference (#4ABE80 / #2F2F2F)
- Daily async check-in channel + twice-weekly review call

## What we need from applicants
- 2–3 links to prior Google Maps API integration work
- Confirmation of availability for a 10-working-day window
- One clarifying question about the brief (screens for read-through)
