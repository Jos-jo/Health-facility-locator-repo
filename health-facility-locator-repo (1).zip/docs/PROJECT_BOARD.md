# Project Board & Management Strategy

## GitHub Projects board (columns)

| Backlog | Ready | In Progress | In Review | Done |
|---|---|---|---|---|
| All 7 issues start here | PM has clarified scope, freelancer can start | Freelancer actively working (1 card max at a time) | PR open, awaiting review | Merged to `dev`, sheet updated |

Each issue card carries: estimate (hrs), price, milestone number, and links
automatically to its PR once one is opened (via `Closes #n` in the PR body).

## Milestones (map to Fiverr payment milestones)

| Milestone | Issues | Trigger to release payment |
|---|---|---|
| M1 — Setup & base map | #01, #02 | Map renders, key restricted, repo access confirmed |
| M2 — Location & search | #03 | Current-location + address search both return correct results |
| M3 — Data & filters | #04, #05 | Facility type/service filters work against sample dataset |
| M4 — Polish & handover | #06, #07 | Responsive on mobile, test notes delivered, `main` deploy green |

## Weekly cadence

- **Daily**: 1-line async status in chat (see `CONTRIBUTING.md`).
- **Twice weekly (Mon/Thu)**: 15-min call/voice note review of open PRs.
- **On milestone completion**: PM reviews against acceptance criteria in the
  issue → approves Fiverr milestone payment → updates Google Sheet.

## How GitHub and the Google Sheet stay in sync

The Sheet is the budget/deadline source of truth; GitHub is the technical
source of truth. They're linked by **issue number**, not duplicated in
detail:

- Sheet's "Task" tab has one row per GitHub issue (same numbering, #01-#07).
- Sheet's "Status" column is manually set to match the board column — PM
  updates this at each check-in rather than trying to auto-sync (no CI
  budget for a GitHub↔Sheets webhook on a single-freelancer engagement).
- Sheet's "PR link" column holds the merged PR URL once done, so budget
  line items are auditable back to actual shipped code.

## Escalation / risk handling

- Slipping >2 days on an active issue → PM checks in same day, not at the
  next scheduled call.
- Two failed review rounds on the same issue → PM pairs briefly (screen
  share) rather than a third silent round-trip.
- Scope creep requests from either side go through a one-line change
  request in the Sheet's "Change Log" tab before any extra hours are billed.
