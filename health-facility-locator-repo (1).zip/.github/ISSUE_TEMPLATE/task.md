---
name: Task
about: A single scoped unit of work on the Health Facility Locator feature
title: "[TASK] "
labels: task
assignees: ''
---

## Description
<!-- What needs to be built, and why. Link to any design/reference. -->

## Acceptance criteria
- [ ]
- [ ]
- [ ]

## Out of scope
<!-- Explicitly name what NOT to build, to prevent scope creep -->

## Estimate
- Hours:
- Price (fixed-price milestone or hourly x hours):

## Dependencies
<!-- e.g. "Blocked by #02" -->
