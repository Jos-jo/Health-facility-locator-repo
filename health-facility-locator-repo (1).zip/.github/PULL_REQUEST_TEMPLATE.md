## Closes
Closes #<issue-number>

## What changed
<!-- Bullet list of the actual changes -->

## How to test
<!-- Steps to run it locally / staging URL -->

## Screenshots / recording
<!-- Required for anything UI-facing -->

## Checklist
- [ ] Meets all acceptance criteria on the linked issue
- [ ] Lint passes (`npm run lint`)
- [ ] No secrets committed
- [ ] Tested on mobile + desktop breakpoints
- [ ] Google Sheet tracker updated (status + actual hours/cost)
