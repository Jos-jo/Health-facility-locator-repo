## Description
Close out the engagement: verify everything against the original brief,
document what was built, and hand over cleanly.

## Acceptance criteria
- [ ] Manual test pass against every acceptance criterion in #01-#06,
      logged in the Sheet's "QA" tab
- [ ] Known issues/edge cases documented (not silently left for later)
- [ ] Short handover note: how filters/data are wired, where the API key
      lives, how to swap the sandbox key for production
- [ ] `main` branch updated from `dev`, deploy verified on staging URL
- [ ] Sandbox API key rotated/revoked post-handover

## Out of scope
Writing automated test suites (not in original scope/budget) — flagged as
a possible future milestone if needed.

## Estimate
- Hours: 3
- Price: Included in M4 milestone

## Dependencies
Blocked by #06.
