## Description
Pair the map with a scrollable list of matching facilities, and a detail
view/panel for a single facility.

## Acceptance criteria
- [ ] List panel beside/below the map, sorted by distance from the search
      center, syncs with map (hover list item highlights marker & vice versa)
- [ ] Each list item shows name, type, distance, open/closed status if
      available
- [ ] Clicking a facility opens a detail panel: full address, phone
      (click-to-call on mobile), services offered, "Get directions" button
      that opens Google Maps directions in a new tab
- [ ] Empty/loading states for the list match the map's empty/loading states

## Out of scope
In-app turn-by-turn directions — deep-link to Google Maps is sufficient.

## Estimate
- Hours: 6
- Price: Included in M3 milestone

## Dependencies
Blocked by #04.
