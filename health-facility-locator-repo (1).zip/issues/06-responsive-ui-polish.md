## Description
Make the whole feature solid on mobile (primary usage context for most
end users) and bring visual polish up to brand standard.

## Acceptance criteria
- [ ] Fully usable on a 360px-wide viewport: filters collapse into a
      bottom-sheet/drawer, map takes priority over list by default
- [ ] Touch targets ≥44px, marker taps open detail panel without map jump
- [ ] Loading skeletons instead of blank states while data fetches
- [ ] Brand colors (#4ABE80 / #2F2F2F) applied consistently across markers,
      buttons, filter chips
- [ ] Passes a basic accessibility pass: color contrast, focus states,
      alt text on icons

## Out of scope
Full WCAG audit — basic pass only, per brief.

## Estimate
- Hours: 5
- Price: Included in M4 milestone

## Dependencies
Blocked by #05.
