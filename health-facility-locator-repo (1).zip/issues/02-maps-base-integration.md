## Description
Render a base Google Map inside the app shell as the foundation the rest of
the feature builds on.

## Acceptance criteria
- [ ] Map component renders full-width on the "Find a facility" page/route
- [ ] Default center = Nigeria bounding box (or user's last known city if
      available); default zoom shows a metro area, not the whole country
- [ ] Map style matches brand palette (#4ABE80 accents on markers/UI chrome)
- [ ] Loads within 2s on a throttled 3G profile (Lighthouse check)
- [ ] API key usage confirmed within sandbox quota (no console warnings)

## Out of scope
Markers for real facilities, geolocation, filters — later issues.

## Estimate
- Hours: 4
- Price: Included in M1 milestone

## Dependencies
Blocked by #01.
