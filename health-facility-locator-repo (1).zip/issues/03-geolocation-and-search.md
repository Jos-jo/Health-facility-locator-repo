## Description
Let the user center the map either on their current device location or on
an address/place they type, using browser geolocation + Places
Autocomplete.

## Acceptance criteria
- [ ] "Use my location" button requests geolocation permission and
      recenters the map; graceful fallback message if permission denied
- [ ] Address search box with Places Autocomplete suggestions as the user
      types, recenters map on selection
- [ ] Search radius is configurable (default 10km) and visibly indicated
      on the map (circle overlay)
- [ ] Handles "no results in radius" state with a clear message + suggestion
      to expand radius

## Out of scope
Actual facility markers/data — this issue is only about positioning.

## Estimate
- Hours: 6
- Price: Included in M2 milestone

## Dependencies
Blocked by #02.
