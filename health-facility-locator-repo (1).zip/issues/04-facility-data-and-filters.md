## Description
Plot facilities from the provided dataset as markers and let the user
filter by facility type and by service offered.

## Acceptance criteria
- [ ] Facilities within the current radius load from the provided JSON/API
      endpoint and render as markers, color-coded by type (hospital,
      clinic, laboratory, pharmacy)
- [ ] Filter panel: multi-select facility type + multi-select service
      (e.g. immunization, radiology); map + list update live on change
- [ ] Marker clustering kicks in above ~30 markers in view to avoid clutter
- [ ] Filters persist in the URL (shareable/bookmarkable link)

## Out of scope
Editing/adding facility data — read-only consumption of the dataset.

## Estimate
- Hours: 8
- Price: Included in M3 milestone

## Dependencies
Blocked by #02. Can run in parallel with #03.
