## Description
Set up the freelancer's local environment against the existing codebase and
confirm access/tooling before any feature work starts.

## Acceptance criteria
- [ ] Repo cloned, `dev` branch checked out, app runs locally
- [ ] Sandbox Google Maps API key received and working (Maps JS + Places
      API enabled, referrer-restricted to staging domain)
- [ ] `.env.example` reviewed, local `.env` created (not committed)
- [ ] Sample facility dataset (anonymized) loaded locally
- [ ] Freelancer added to GitHub repo (write) and the Google Sheet (comment)

## Out of scope
Any actual map or UI code — this is environment/access only.

## Estimate
- Hours: 2
- Price: Included in M1 milestone

## Dependencies
None — first task.
